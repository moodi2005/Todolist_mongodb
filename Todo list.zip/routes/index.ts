const Todo = require('../models/todo.ts');

const express = require('express')
const router = express.Router();

router.use("/", (req,res)=>{
    Todo.countDocuments({ finish: true}).then(finish=>{
      Todo.find().then((todos) => {
          res.render("index", {
              pageTitle: "کارهای روزمره",
              todos,
              completedTodos:finish,
              remainingTodos:todos.length-finish,
          });
      });
    })
  });


module.exports = router;
