const Todo = require('../models/todo.ts');

const express = require('express')
const router = express.Router();

router.get("/finish/:id",(req, res) => {
    Todo.findById(req.params.id)
    .then((todo) => {
        todo.finish = true;
        return todo.save();
    })
    .then(() => res.redirect("/"))
    .catch((err) => console.log(err));
    })


    module.exports = router;
