const Todo = require('../models/todo.ts');

const express = require('express')
const router = express.Router();

router.use("/admin",(req,res)=>{
    Todo.create({ text: req.body.text })
    .then((result) => {
        res.redirect("/");
    })
    .catch((err) => console.log(err));
  })
  
  module.exports = router;
