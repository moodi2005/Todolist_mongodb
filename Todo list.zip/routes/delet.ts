const Todo = require('../models/todo.ts');

const express = require('express')
const router = express.Router();

router.get("/delet/:id",(req, res) => {
    Todo.findByIdAndRemove(req.params.id)
        .then(() => res.redirect("/"))
        .catch((err) => console.log(err));
  });

  module.exports = router;
