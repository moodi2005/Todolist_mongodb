const express = require("express");
const { static } = require("./utils/static.ts");
const bodyParser = require("body-parser");

const index = require("./routes/index.ts");
const admin = require("./routes/admin.ts");
const delet = require("./routes/delet.ts");
const finish = require("./routes/finish.ts");
// const sequelize = require("./utils/databeat.ts");

const app = express();
const port = 5000;

require('./utils/mongoos.ts');

app.set("view engine", "ejs");

app.use(bodyParser.urlencoded({ extended: false }));
static(app);

app.use(admin);
app.use(delet);
app.use(finish);
app.use(index);

// sequelize
//   .sync()
//   .then((result) => {
    //   })
    //   .catch((err) => {
        //     console.log(err);
        //   });
app.listen(3000, () => console.log(`Server is running.`));
