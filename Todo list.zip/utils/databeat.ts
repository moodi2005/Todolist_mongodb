const {Sequelize} = require('sequelize');

const sequelize = new Sequelize("todo","root","moodi123.321",{
    host:"localhost",
    dialect:"mysql"
});


module.exports=sequelize;

