// const {DataTypes} = require("sequelize");

// import { model } from "mongoose";

// const sequelize =require('../utils/databeat.ts');

// const Todo = sequelize.define('ali', {
//    id:{
//     type: DataTypes.INTEGER,
//     autoIncrement: true,
//     primaryKey: true,
//     allowNull: false,
//    },
//    text:{
//        type:DataTypes.STRING,
//        allowNull:false
//    },
//    finish:{
//        type:DataTypes.BOOLEAN,
//        allowNull:true,
//        defaultValue:false,
//    },
//   });
  
// module.exports=Todo;
const mongoose = require("mongoose");

const todoSchema = new mongoose.Schema({
    text: {
        type: String,
        required: true,
        trim: true,
        minlength: 3,
        max: 255,
    },
    finish: {
        type: Boolean,
        required: false,
        default: false,
    },
});

const Todo = mongoose.model("Todo", todoSchema);

module.exports = Todo;
